package interfaxChiva;
import chiva.*;
public class interfaxChiva {

	public static void main(String[] args) {
		
		
	chivaRumbera chivaRumbera1;
	
	chivaRumbera1 = new chivaRumbera("ibague", 32, 22, 20000.0, 2500.0, 8);
	
	System.out.println(chivaRumbera1.getNombre());
	}
}
