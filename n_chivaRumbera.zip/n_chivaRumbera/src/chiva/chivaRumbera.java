package chiva;

public class chivaRumbera
{
		
		private String nombre; 
		private int    capacidad;
		private int cantidadSillas;
		private double precioPagar;
		private double precioHora;
		private double    horaAlquiler;
		
		public chivaRumbera( String pNombre, int pCapacidad, int pCantidadSillas, double pPrecioPagar, double pPrecioHora, double pHoraAlquiler)
		{
			nombre= pNombre;
			capacidad= pCapacidad;
			cantidadSillas= pCantidadSillas;
			precioPagar= pPrecioPagar;
			precioHora= pPrecioHora;
			horaAlquiler= pHoraAlquiler;
		}
		
		public double calcularTotalPagar()
		{
			return precioHora * horaAlquiler; 
		
		}
		
		public String getNombre()
		{
			return nombre;
		}
		
		public int getCapacidad()
		{
			return capacidad;
		}
		
		public int getCantidadSillas()
		{
			return cantidadSillas;
		}
		
		public double getPrecioPagar()
		{
			return precioPagar;
		}
		
		public double  getPrecioHora()
		{
			return  precioHora;
		}
		
		public double getHoraAlquiler()
		{
			return horaAlquiler;
		}
		
		public void setNombre(String pNombre)
		{
			nombre=pNombre;
		}
		
		public void setCapacidad(int pCapacidad)
		{
			capacidad=pCapacidad;
		}
		
		public void setCantidadSillas(int pCantidadSillas)
		{
			cantidadSillas=pCantidadSillas;
		}
		
		public void setPrecioPagar(int pPrecioPagar)
		{
			precioPagar=pPrecioPagar;
		}
		public void setPrecioHora(int pPrecioPagar)
		{
			precioPagar=pPrecioPagar;
		}
		
		public void setHoraAlquiler(int pHoraAlquiler)
		{
			horaAlquiler=pHoraAlquiler;
		}
		
		
		

	
}
